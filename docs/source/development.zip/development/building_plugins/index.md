Building plugins
==================

```{toctree}
:maxdepth: 1

types
structure
plugin_triggers
drag_and_drop
icons
limit_creation
global_settings
status_bar
actions/index
learning_center/index
